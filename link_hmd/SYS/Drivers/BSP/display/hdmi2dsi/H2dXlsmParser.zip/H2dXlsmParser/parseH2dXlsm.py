# -*- coding: utf-8 -*- 
import os
import  xdrlib ,sys
import xlrd
import struct
import logging
import subprocess

START_ROW1 = 6
END_ROW1 = 118
START_ROW2 = 375
END_ROW2 = 700

CB_S_ROW1 = 6
CB_E_ROW1 = 118
CB_S_ROW2 = 375
CB_E_ROW2 = 399

FPS_POSITION = (19, 12)

def open_excel(file= 'h2d.xlsm'):
    try:
        data = xlrd.open_workbook(file)
        return data
    except Exception,e:
        print str(e)

def excel_table_byname(file= 'h2d.xlsm',row_range=range(6,118),by_name=u'Source_Startup'):
    data = open_excel(file)
    sheet = data.sheet_by_name(by_name)
    list =[]
    for rownum in row_range:
         row = sheet.row_values(rownum)
         cmd = row[1]
         if cmd == "WR16" or cmd == "WR32" or cmd == "WR8":
             if cmd == "WR16":
                 type = 16
             if cmd == "WR32":
                 type = 32
             if cmd == "WR8":
                 type = 8
             addr = row[3]
             data = row[4]
             app = (type, addr, data)
             list.append(app)
         if cmd == "delay":
             type = 255
             addr = row[3]
             app = (type, addr, 0)
             list.append(app)
    return list

def table2binary(f, tbl, bBinary):
   chksum = 0
   for row in tbl:
     #print row
     if row[0] != 255:
        size = int(row[0])
        addr = int(row[1], 16)
        data = int(row[2], 16)
        if addr == 0x8C18:
           data = 0x12
        if addr >= 0x8C84 and addr <= 0x8C8B:
           data = 0x0
        if addr >= 0x8C00 and addr <= 0x8C7E:
           chksum += data
        if addr == 0x8C7F:
           data = 0x100 - (chksum&0xFF)
           chksum = 0
        if addr > 0x8C7F and addr < 0x8CFF:
           chksum += data
        if addr == 0x8CFF:
           data = 0x100 - (chksum&0xFF)
        if bBinary:
           bytes=struct.pack('iii',size,addr,data)
           f.write(bytes)
        else:
           line = '{0x%02x,0x%04x,0x%x},\n'%(size,addr,data)
           f.write(line)
     if row[0] == 255:
        size = int(row[0])
        addr = int(row[1])
        data = int(row[2])
        if bBinary:
           bytes=struct.pack('iii', size,addr,data)
           f.write(bytes)
        else:
           line = '{0x%02x,0x%04x,0x%x},\n'%(size,addr,data)
           f.write(line)
   return

def excel2binary(f, file, row_range, sheet_name, bBinary):
   tbl = excel_table_byname(file, row_range, sheet_name)
   size = len(tbl)
   print "%i"%size + " lines converted."
   if bBinary:
      bytes=struct.pack('i', size)
      f.write(bytes)
   table2binary(f, tbl, bBinary)
   return

def getFps(file):
    data = open_excel(file)
    sheet = data.sheet_by_name(u'Main_Parameters')
    cellFps = sheet.cell(FPS_POSITION[0], FPS_POSITION[1])
    fps = cellFps.value
    print "fps is %f" % fps
    return fps

def make_h2d_head(file, name, _fps):
    uname = name.upper()
    tmp_line = '#ifndef __%s_VIDEO_TIMING_H__\n' % uname
    tmp_line += '#define __%s_VIDEO_TIMING_H__\n' % uname
    tmp_line += '\n'
    tmp_line += '#define %s_H2D_MAGIC  (0x68326473)\n' % uname
    tmp_line += '#define %s_DP_SOURCE_FPS  (%f)\n' % (uname, _fps)
    tmp_line += '\n'
    tmp_line += '#if COLOR_BAR_TEST\n'
    tmp_line += 'static const reg_item %s_colorbar_phase1_tbl[] = {\n' % name
    tmp_line += '    #include "ColorBarPhase1_%s.tbl"\n' % name
    tmp_line += '};\n'
    tmp_line += 'static const reg_item %s_colorbar_phase2_tbl[] = {\n' % name
    tmp_line += '    #include "ColorBarPhase2_%s.tbl"\n' % name
    tmp_line += '};\n'
    tmp_line += '#endif\n'
    tmp_line += '\n'
    tmp_line += 'static const reg_item %s_startup_phase1_tbl[] = {\n'% name
    tmp_line += '    #include "StartupPhase1_%s.tbl"\n' % name
    tmp_line += '};\n'
    tmp_line += '\n'
    tmp_line += 'static const reg_item %s_startup_phase2_tbl[] = {\n' % name
    tmp_line += '    #include "StartupPhase2_%s.tbl"\n' % name
    tmp_line += '};\n'
    tmp_line += '\n'
    tmp_line += 'static const h2d_tbl_t %s_h2d_tbl = {\n' % name
    tmp_line += '    %s_H2D_MAGIC,\n' % uname
    tmp_line += '    %s_DP_SOURCE_FPS,\n' % uname
    tmp_line += '    sizeof(%s_startup_phase1_tbl)/sizeof(%s_startup_phase1_tbl[0]),\n' % (name, name)
    tmp_line += '    %s_startup_phase1_tbl,\n' % name
    tmp_line += '    sizeof(%s_startup_phase2_tbl)/sizeof(%s_startup_phase2_tbl[0]),\n' % (name, name)
    tmp_line += '    %s_startup_phase2_tbl,\n' % name
    tmp_line += '#if COLOR_BAR_TEST\n'
    tmp_line += '    sizeof(%s_colorbar_phase1_tbl)/sizeof(%s_colorbar_phase1_tbl[0]),\n' % (name, name)
    tmp_line += '    %s_colorbar_phase1_tbl,\n' % name
    tmp_line += '    sizeof(%s_colorbar_phase2_tbl)/sizeof(%s_colorbar_phase2_tbl[0]),\n' % (name, name)
    tmp_line += '    %s_colorbar_phase2_tbl\n' % name
    tmp_line += '#else\n'
    tmp_line += '    0,\n'
    tmp_line += '    0,\n'
    tmp_line += '    0,\n'
    tmp_line += '    0\n'
    tmp_line += '#endif\n'
    tmp_line += '};\n'
    tmp_line += '\n'
    tmp_line += '#endif //__%s_VIDEO_TIME_H__\n' % uname
    file.write(tmp_line)


def main():
   argc = len(sys.argv)
   if (argc != 3):
      print "Error args! Format:python parseH2dXlsm.py h2d.xlsm h2d.dfu"
      return
   
   (filepath,tempfilename) = os.path.split(sys.argv[2]);
   (shotname,extension) = os.path.splitext(tempfilename)

   fps = getFps(sys.argv[1])
   if extension == ".bin" or extension == ".dfu":
      if extension == ".bin":
         f = open(sys.argv[2], "wb")
      else:
         f = open("tmp.bin", "wb")
      bytes=struct.pack('if', 0x68326473, fps)
      f.write(bytes)
      excel2binary(f, sys.argv[1], range(START_ROW1,END_ROW1), u'Source_Startup', True)
      excel2binary(f, sys.argv[1], range(START_ROW2,END_ROW2), u'Source_Startup', True)
      excel2binary(f, sys.argv[1], range(CB_S_ROW1,CB_E_ROW1), u'Source_ColorBar', True)
      excel2binary(f, sys.argv[1], range(CB_S_ROW2,CB_E_ROW2), u'Source_ColorBar', True)
      f.close()
   if extension == ".tbl":
      f = open(filepath+"\\"+shotname+"_video_timing.h", "w")
      make_h2d_head(f, shotname, fps)
      f.close()
      f = open(filepath+"\\StartupPhase1_"+shotname+extension, "w")
      excel2binary(f, sys.argv[1], range(START_ROW1,END_ROW1), u'Source_Startup', False)
      f.close()
      f = open(filepath+"\\StartupPhase2_"+shotname+extension, "w")
      excel2binary(f, sys.argv[1], range(START_ROW2,END_ROW2), u'Source_Startup', False)
      f.close()
      f = open(filepath+"\\ColorBarPhase1_"+shotname+extension, "w")
      excel2binary(f, sys.argv[1], range(CB_S_ROW1,CB_E_ROW1), u'Source_ColorBar', False)
      f.close()
      f = open(filepath+"\\ColorBarPhase2_"+shotname+extension, "w")
      excel2binary(f, sys.argv[1], range(CB_S_ROW2,CB_E_ROW2), u'Source_ColorBar', False)
      f.close()
   
   if extension == ".dfu":
      INTERPRETER = "C:\Python27\python.exe"
      if not os.path.exists(INTERPRETER):
         log.error("Cannot find INTERPRETER at path \"%s\"." % INTERPRETER)
         INTERPRETER = "python.exe"
      processor = "dfu-convert"
      pargs = [INTERPRETER, processor]
      pargs.extend(["-b 0x08020000:tmp.bin"])
      pargs.extend([sys.argv[2]])
      subprocess.Popen(pargs) 
   print "convert success."

if __name__=="__main__":
    main()
